﻿using System;
using System.Collections.Generic;

namespace TFTStatUtmutato_Backend.Models;

public partial class Augment
{
    public int AugmentId { get; set; }

    public string Name { get; set; } = null!;

    public string? Effect { get; set; }

    public string Rarity { get; set; } = null!;
}
