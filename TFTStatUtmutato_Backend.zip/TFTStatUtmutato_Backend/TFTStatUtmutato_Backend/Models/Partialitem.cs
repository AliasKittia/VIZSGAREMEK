﻿using System;
using System.Collections.Generic;

namespace TFTStatUtmutato_Backend.Models;

public partial class Partialitem
{
    public int PartialItemId { get; set; }

    public string Name { get; set; } = null!;

    public string? Effect { get; set; }

    public virtual ICollection<Fullitem> FullItems { get; set; } = new List<Fullitem>();
}
