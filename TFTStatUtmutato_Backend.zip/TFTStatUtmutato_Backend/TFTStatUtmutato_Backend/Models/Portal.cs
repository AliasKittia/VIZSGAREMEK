﻿using System;
using System.Collections.Generic;

namespace TFTStatUtmutato_Backend.Models;

public partial class Portal
{
    public int PortalId { get; set; }

    public string Name { get; set; } = null!;

    public string? Effect { get; set; }
}
