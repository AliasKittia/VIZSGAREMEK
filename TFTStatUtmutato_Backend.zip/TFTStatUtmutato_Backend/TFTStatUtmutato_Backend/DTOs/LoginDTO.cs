﻿namespace TFTStatUtmutato_Backend.DTOs
{
    public class LoginDTO
    {
        public string LoginNev { get; set; }
        public string TmpHash { get; set; }
    }
}
