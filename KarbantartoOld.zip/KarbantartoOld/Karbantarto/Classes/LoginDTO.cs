﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karbantarto.Classes
{
    public class LoginDTO
    {
        public string LoginName { get; set; }

        public string TmpHash { get; set; }
    }
}
