﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Karbantarto.Classes
{
    public class AnomaliaLekeresDTO
    {
        public int AnomalyId { get; set; }
        public string? AnomalyName { get; set; }
        public string? AnomalyEffect { get; set; }
    }
}
