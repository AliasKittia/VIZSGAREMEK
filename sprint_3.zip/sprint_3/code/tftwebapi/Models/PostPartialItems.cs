namespace tftwebapi.Models

{
    public class PostPartialItems
    {
        public required int partial_item_id { get; set; }
        public required string name { get; set; }
        public required string effect { get; set; }
    }
}