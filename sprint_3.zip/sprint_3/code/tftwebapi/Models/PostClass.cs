namespace tftwebapi.Models
{
    public class PostClass
    {
        public required int ClassId { get; set; }
        public required string ClassName { get; set; }
        public required string BasicEffect { get; set; }
    }
}