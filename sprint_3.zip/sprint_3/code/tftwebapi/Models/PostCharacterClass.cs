namespace tftwebapi.Models;

public class PostCharacterClass{
    public required int CharacterId { get; set; }
    public required int ClassId { get; set; }
}